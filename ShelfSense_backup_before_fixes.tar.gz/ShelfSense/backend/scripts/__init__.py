"""Developer scripts for ShelfSense."""
