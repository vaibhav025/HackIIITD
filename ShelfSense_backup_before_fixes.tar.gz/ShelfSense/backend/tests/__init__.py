"""ShelfSense tests."""
